<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <script src="js/jquery-331.min.js"></script>
    <script src="https://apis.google.com/js/platform.js" async defer></script>
	<title>Paypal Payment</title>
</head>
<body>
	<div class="container">
		<h2>Welcome Customer!</h2>
		<h3>You have successfully paid for this product</h3>
		<a href="customer/my_account.php">Go to My account</a>
	</div>
</body>
</html>