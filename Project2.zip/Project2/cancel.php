<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <script src="js/jquery-331.min.js"></script>
    <script src="https://apis.google.com/js/platform.js" async defer></script>
	<title>Paypal Payment</title>
</head>
<body>
	<div class="container">
		<h2>You have canceled the payment!</h2>
		<h3>Go back to the shop</h3>
		<button class="btn btn-primary">
			<i class="fa fa-arrow-left"></i> <a href="shop.php" style="color: black;">Go to Shop</a>
		</button>
	</div>
</body>
</html>