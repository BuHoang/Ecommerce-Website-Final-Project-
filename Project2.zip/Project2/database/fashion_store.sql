-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 31, 2020 at 09:58 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fashion_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_id` int(10) NOT NULL,
  `brand_title` text NOT NULL,
  `brand_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_title`, `brand_desc`) VALUES
(1, 'Prada', 'This is the brand related to Prada company'),
(2, 'Canifa', 'This is the brand related to Canifa company'),
(3, 'H&M', 'This is the brand related to H&M company'),
(4, 'Zara', 'This is the brand related to Zara company'),
(5, 'Other', 'This is the brand related to Other');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(10) NOT NULL,
  `cat_title` text NOT NULL,
  `cat_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`, `cat_desc`) VALUES
(1, 'Vest', 'This is the category including with all Vest shirts and Vest suits'),
(2, 'Jacket', 'This is the category including with all Jacket'),
(3, 'T-shirt', 'This is the category including with all T-shirt'),
(4, 'Sport', 'This is the category including with all Sport suits'),
(5, 'Coat', 'This is the category including with all Coat');

-- --------------------------------------------------------

--
-- Table structure for table `procloth`
--

CREATE TABLE `procloth` (
  `product_id` int(10) NOT NULL,
  `cat_id` int(10) NOT NULL,
  `brand_id` int(10) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `product_title` text NOT NULL,
  `product_img1` text NOT NULL,
  `product_img2` text NOT NULL,
  `product_img3` text NOT NULL,
  `product_price` int(100) NOT NULL,
  `product_desc` text NOT NULL,
  `product_keywords` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `procloth`
--

INSERT INTO `procloth` (`product_id`, `cat_id`, `brand_id`, `date`, `product_title`, `product_img1`, `product_img2`, `product_img3`, `product_price`, `product_desc`, `product_keywords`) VALUES
(1, 2, 1, '2020-05-27 14:34:11', 'Slim Fit Solid Men Bomber Jacket', 'jacket-1.jpg', 'jacket-1.1.jpg', 'jacket-1.2.jpg', 56, '<p><span style=\"font-size: 14px;\">This is a slim jacket for men with durable material and made in China</span></p>', 'Bomber'),
(2, 3, 2, '2020-05-28 03:12:26', 'Summer T-shirt Three Types For Men', 't-shirt.jpg', 't-shirt-1.jpg', 't-shirt-2.jpg', 70, '<p><span style=\"font-size: 14px;\">This is a summer T-shirt with three types for men accompanied by high quality and reasonable price</span></p>', 'Summer T-shirt '),
(3, 1, 2, '2020-05-28 03:22:33', 'Men Fitness Hoodies Tank Tops Vest', 'vest.jpg', 'vest-1.jpg', 'vest-2.jpg', 45, '<p><span style=\"font-size: 14px;\">This is a Men Fitness Hoodies Vest with three types for men accompanied by high quality and reasonable price</span></p>\r\n<p>&nbsp;</p>', 'Tank Tops'),
(4, 5, 2, '2020-05-28 06:27:36', 'Mens Overcoat Fashion Autumn Winter Button ', 'coat.jpg', 'coat-1.jpg', 'coat-2.jpg', 48, '<p><span style=\"font-size: 14px;\">This is a Men Overcoat Fashion Autumn Winter Button with three types for men accompanied by high quality and reasonable price</span></p>', 'Overcoat'),
(5, 4, 3, '2020-05-28 06:45:25', 'Bodybuilding Skull Rash guard Men Sport', 'sport-skull.jpg', 'sport-skull-1.jpg', 'sport-skull-2.jpg', 67, '<p><span style=\"font-size: 14px;\">This is a Bodybuilding Skull suit with three types for men accompanied by high quality and reasonable price</span></p>', 'Bodybuilding Skull'),
(6, 5, 4, '2020-05-28 06:54:27', 'Winter Coat Women Work Solid Vintage', 'Winter-Coat-Women.jpg', 'Winter-Coat-Women-1.jpg', 'Winter-Coat-Women-2.jpg', 80, '<p><span style=\"font-size: 14px;\">This is a Winter Coat Women with three types for women accompanied by high quality and reasonable price</span></p>\r\n<p>&nbsp;</p>', 'Winter Coat'),
(7, 1, 3, '2020-05-28 07:10:51', 'Women Vest Cotton Hooded', 'Vest-Cotton.jpg', 'Vest-Cotton-1.jpg', 'Vest-Cotton-2.jpg', 100, '<p><span style=\"font-size: 14px;\">This is a Vest Cotton Hooded with three types for women accompanied by high quality and reasonable price</span></p>\r\n<p>&nbsp;</p>', 'Vest Cotton'),
(8, 3, 2, '2020-05-28 07:20:02', 'T-Shirts Women Fashion Graphic Print', 'T Shirts-Women.jpg', 'T Shirts-Women-1.jpg', 'T Shirts-Women-2.jpg', 110, '<p><span style=\"font-size: 14px;\">This is a T-Shirt Women Fashion Graphic Print with three types for women accompanied by high quality and reasonable price</span></p>', 'Graphic Print'),
(9, 3, 4, '2020-05-30 11:46:53', '3D printed Image Men T-shirt ', '3D printed t-shirt.jpg', '3D printed t-shirt-1.jpg', '3D printed t-shirt-2.jpg', 85, '<p><span style=\"font-size: 14px;\">3D printed Image T-shirt for men with three types accompanied by high quality and reasonable price</span></p>', '3D printed');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `slide_id` int(10) NOT NULL,
  `slide_name` varchar(255) NOT NULL,
  `slide_image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`slide_id`, `slide_name`, `slide_image`) VALUES
(1, 'Slide number 1', 'ad1.jpg'),
(2, 'Slide number 2', 'ad2.jpg'),
(3, 'Slide number 3', 'ad3.jpg'),
(4, 'Slide number 4', 'ad4.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `procloth`
--
ALTER TABLE `procloth`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`slide_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `procloth`
--
ALTER TABLE `procloth`
  MODIFY `product_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `slide_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
