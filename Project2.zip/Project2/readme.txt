cài đặt composer thông qua cmd 
composer require google/apiclient:"^2.0"