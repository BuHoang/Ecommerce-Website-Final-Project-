<?php
	$con = mysqli_connect("localhost", "root", "", "fashion_store");
?>